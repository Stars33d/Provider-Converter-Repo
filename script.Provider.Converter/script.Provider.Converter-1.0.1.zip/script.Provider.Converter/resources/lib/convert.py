# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui
import os
import re
import json
import zipfile
from io import BytesIO
from datetime import datetime

try:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
except:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

# Uncomment the block below in the future, when Seren comes with the zlib module
# and is able to decompress packages.
useCompression = False
'''try:
    # zlib module is optional, see if it's available.
    import zlib
    useCompression = True
except ImportError:
    # zlib module is not available, don't compress any files, just store them in the archive.
    useCompression = False'''

CURRENT_TIME = datetime.now()

serenModulesFolder = 'providerModules'
serenProvidersFolder = 'providers'

memoryBuffer = BytesIO()

#This gets written to the __init__ file within the language folders
languageInitContent ="\
    \n# -*- coding: utf-8 -*-\
    \n\nimport hosters\
    \nimport torrent\
    \n\ndef get_hosters():\
    \n    return hosters.__all__\
    \n\ndef get_torrent():\
    \n    return torrent.__all__\
    \n"

#This gets written to the __init__ files for both 'hosters' and 'torrent' folders
scrapersInitContent = "\
    \n# -*- coding: utf-8 -*-\
    \n\nimport os.path\
    \n\nfiles = os.listdir(os.path.dirname(__file__))\
    \n\n__all__ = [filename[:-3] for filename in files if not filename.startswith('__') and filename.endswith('.py')]\
    \n"

#zipPath = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages')) if xbmcaddon.Addon().getSetting('Enable.ZipPath') == False else xbmc.translatePath(xbmcaddon.Addon().getSetting('Custom.ZipPath'))
serenZips = xbmc.translatePath(os.path.join(dataPath, 'SerenProviderZips'))
if not os.path.exists(serenZips):
	try: os.makedirs(serenZips)	
	except: pass
zipPath = serenZips if not xbmcaddon.Addon().getSetting('Enable.ZipPath') == False else xbmc.translatePath(xbmcaddon.Addon().getSetting('Custom.ZipPath'))
	
##########################################################################################################################

# Package info.
PACKAGE1_NAME = 'LambdaScrapers_Unofficial' # Also used as folder name.
#PACKAGE1_NUM = '0.3'
PACKAGE1_NUM = xbmcaddon.Addon('script.module.lambdascrapers').getAddonInfo('version')
PACKAGE1_VERSION = '%s_%s' % (PACKAGE1_NUM, CURRENT_TIME.strftime('%m-%d-%Y'))
PACKAGE1_AUTHOR = 'Provider_Converter_v%s' % xbmcaddon.Addon().getAddonInfo('version')

#lambdaFolderPath = os.path.join(os.path.dirname(__file__), 'lib', 'lambdascrapers')
lambdaModule = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.module.lambdascrapers'))
lambdaFolderPath = os.path.join(lambdaModule, 'lib', 'lambdascrapers')

importPattern = re.compile(r'(from\s*?)(((resources\s*?\.\s*?lib)|(lambdascrapers))\s*?\.?\s*?modules)')
importReplace = r'\1' + serenModulesFolder + '.' + PACKAGE1_NAME

def LambdaScrapers(install=False):
	with zipfile.ZipFile(memoryBuffer, 'w', zipfile.ZIP_DEFLATED if useCompression else zipfile.ZIP_STORED) as packageZIP:

		# 1) Pack the meta file.
		packageZIP.writestr(
			'meta.json', json.dumps({'name': PACKAGE1_NAME, 'version': PACKAGE1_VERSION, 'author': PACKAGE1_AUTHOR})
		)

		# 2) Pack the provider modules.
		modulesPath = os.path.join(lambdaFolderPath, 'modules')
		for dirPath, dirNames, fileNames in os.walk(modulesPath):
			subFolder = dirPath.replace(modulesPath, '').strip(os.sep)
			zipModulesPath = os.path.join(serenModulesFolder, PACKAGE1_NAME, subFolder)
			if (subFolder == '' or subFolder == 'cfscrape'):
				for fileName in fileNames:
					# On each script, replace references to 'lambdascrapers.modules' with a new path.
					moduleFile = open(os.path.join(dirPath, fileName), 'r')
					script = moduleFile.read()
					moduleFile.close()
					script = re.sub(importPattern, importReplace, script)
					packageZIP.writestr(os.path.join(zipModulesPath, fileName), script)
			else:
				for fileName in fileNames:
					packageZIP.write(os.path.join(dirPath, fileName), os.path.join(zipModulesPath, fileName))
					

		# 3) Pack the provider scripts.
		# - Only the language folders are stored right now. The en_DebridOnly folder is ignored.
		# - Any references to 'resources.lib.modules' in the scripts are changed to use 'providerModules' from above.
		languageFoldersPath = os.path.join(lambdaFolderPath, 'sources_ lambdascrapers')
		zipProvidersPath = os.path.join(serenProvidersFolder, PACKAGE1_NAME)
		for languageFolder in os.listdir(languageFoldersPath):
			if '.py' not in languageFolder and 'debrid' not in languageFolder.lower():
				# Make an __init__.py with some specific code on each language folder (Seren requirement).
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, '__init__.py'), languageInitContent)
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'hosters', '__init__.py'), scrapersInitContent)
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'torrent', '__init__.py'), scrapersInitContent)

				# add provider language folder and contents to zip file
				languageFolderPath = os.path.join(languageFoldersPath, languageFolder)
				for entry in os.listdir(languageFolderPath):
					if entry.endswith('.py'):
						providerFile = open(os.path.join(languageFolderPath, entry), 'r')
						script = providerFile.read()
						providerFile.close()
						# Replace references to 'resources.lib.modules' on each script with the new path.
						script = re.sub(importPattern, importReplace, script)
						packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'hosters', entry), script)

				# add en_DebridOnly folder contents to zip file
				DebridFolderPath = os.path.join(languageFoldersPath, 'en_DebridOnly')
				for entry in os.listdir(DebridFolderPath):
					if entry.endswith('.py'):
						providerFile = open(os.path.join(DebridFolderPath, entry), 'r')
						script = providerFile.read()
						providerFile.close()
						# Replace references to 'resources.lib.modules' on each script with the new path.
						script = re.sub(importPattern, importReplace, script)
						# Remove debrid.status Exceptions
						script = script.replace('if debrid.status() is False: raise Exception()', '')
						script = script.replace('if debrid.status() == False: raise Exception()', '')
						#script = script.replace('resources.lib.modules', serenModulesFolder + '.' + PACKAGE1_NAME)
						#script = script.replace('lambdascrapers.modules', 'providerModules.LambdaScrapers')

						packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'hosters', entry), script)	

		packageZIP.writestr(os.path.join(zipProvidersPath, '__init__.py'), '')

	# Write the final zip file outside of the 'with' context above, so the operations are complete.
	#outputPath = os.path.join(os.path.dirname(__file__), '%s_for_Seren_%s.zip' % (PACKAGE1_NAME, CURRENT_TIME.strftime('%Y-%m-%d')))
	outputFile = '%s_for_Seren_v%s_%s.zip' % (PACKAGE1_NAME, PACKAGE1_NUM, CURRENT_TIME.strftime('%m-%d-%Y'))
	outputPath = os.path.join(zipPath, outputFile)
	with open(outputPath, 'wb') as output:
		memoryBuffer.seek(0)
		output.write(memoryBuffer.getvalue())

	xbmcgui.Dialog().ok('Conversion Complete', '[B]Zip File Destination:[/B]', zipPath + '\\' + outputFile)

	# 4) Install the Provider Zip.
	if install == True:
		if xbmcgui.Dialog().yesno('Provider Converter', ' ', 'Would you like to Install the Generated Package?', outputFile):
			xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=installProviders&actionArgs=0)')
		else:
			pass

##########################################################################################################################

# Package info.
PACKAGE2_NAME = 'YodaScrapers_Unofficial' # Also used as folder name.
#PACKAGE2_NUM = '1.00.045'
PACKAGE2_NUM = xbmcaddon.Addon('script.module.Yoda').getAddonInfo('version')
PACKAGE2_VERSION = '%s_%s' % (PACKAGE2_NUM, CURRENT_TIME.strftime('%m-%d-%Y'))
PACKAGE2_AUTHOR = 'Provider_Converter_v%s' % xbmcaddon.Addon().getAddonInfo('version')

#YodaFolderPath = os.path.join(os.path.dirname(__file__), 'lib', 'resources', 'lib')
YodaModule = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.module.Yoda'))
YodaFolderPath = os.path.join(YodaModule, 'lib', 'resources', 'lib')
	
def YodaScrapers(install=False):
	with zipfile.ZipFile(memoryBuffer, 'w', zipfile.ZIP_DEFLATED if useCompression else zipfile.ZIP_STORED) as packageZIP:
		
		# 1) Pack the meta file.
		packageZIP.writestr(
			'meta.json', json.dumps({'name': PACKAGE2_NAME, 'version': PACKAGE2_VERSION, 'author': PACKAGE2_AUTHOR})
		)

		# 2) Pack the provider modules.
		modulesPath = os.path.join(YodaFolderPath, 'modules')
		for dirPath, dirNames, fileNames in os.walk(modulesPath):
			subFolder = dirPath.replace(modulesPath, '').strip(os.sep)
			zipModulesPath = os.path.join(serenModulesFolder, PACKAGE2_NAME, subFolder)
			if (subFolder == '' or subFolder == 'cfscrape'):
				for fileName in fileNames:
					# On each script, replace references to 'lambdascrapers.modules' with a new path.
					moduleFile = open(os.path.join(dirPath, fileName), 'r')
					script = moduleFile.read()
					moduleFile.close()
					#script = re.sub(importPattern, importReplace, script)
					script = script.replace('resources.lib.modules', serenModulesFolder + '.' + PACKAGE2_NAME)

					packageZIP.writestr(os.path.join(zipModulesPath, fileName), script)
			else:
				for fileName in fileNames:
					packageZIP.write(os.path.join(dirPath, fileName), os.path.join(zipModulesPath, fileName))

		# 3) Pack the provider scripts.
		# - Only the language folders are stored right now. The en_DebridOnly folder is ignored.
		# - Any references to 'resources.lib.modules' in the scripts are changed to use 'providerModules' from above.
		languageFoldersPath = os.path.join(YodaFolderPath, 'sources')
		zipProvidersPath = os.path.join(serenProvidersFolder, PACKAGE2_NAME)
		for languageFolder in os.listdir(languageFoldersPath):
			if '.py' not in languageFolder and 'debrid' not in languageFolder.lower():
				# Make an __init__.py with some specific code on each language folder (Seren requirement).
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, '__init__.py'), languageInitContent)
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'hosters', '__init__.py'), scrapersInitContent)
				packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'torrent', '__init__.py'), scrapersInitContent)

				# add provider language folder and contents to zip file
				languageFolderPath = os.path.join(languageFoldersPath, languageFolder)
				for entry in os.listdir(languageFolderPath):
					if entry.endswith('.py'):
						providerFile = open(os.path.join(languageFolderPath, entry), 'r')
						script = providerFile.read()
						providerFile.close()
						# Replace references to 'resources.lib.modules' on each script with the new path.
						#script = re.sub(importPattern, importReplace, script)
						script = script.replace('resources.lib.modules', serenModulesFolder + '.' + PACKAGE2_NAME)

						# Remove debrid.status Exceptions
						script = script.replace('if debrid.status() is False: raise Exception()', '')
						script = script.replace('if debrid.status() == False: raise Exception()', '')
						#script = script.replace('resources.lib.modules', serenModulesFolder + '.' + PACKAGE2_NAME)
						#script = script.replace('lambdascrapers.modules', 'providerModules.LambdaScrapers')		

						packageZIP.writestr(os.path.join(zipProvidersPath, languageFolder, 'hosters', entry), script)

		packageZIP.writestr(os.path.join(zipProvidersPath, '__init__.py'), '')
	
	# Write the final zip file outside of the 'with' context above, so the operations are complete.
	#outputPath = os.path.join(os.path.dirname(__file__), '%s_for_Seren_%s.zip' % (PACKAGE2_NAME, CURRENT_TIME.strftime('%Y-%m-%d')))
	outputFile = '%s_for_Seren_v%s_%s.zip' % (PACKAGE2_NAME, PACKAGE2_NUM, CURRENT_TIME.strftime('%m-%d-%Y'))
	outputPath = os.path.join(zipPath, outputFile)
	with open(outputPath, 'wb') as output:
		memoryBuffer.seek(0)
		output.write(memoryBuffer.getvalue())

	xbmcgui.Dialog().ok('Conversion Complete', '[B]Zip File Destination:[/B]', zipPath + '\\' + outputFile)

	# 4) Install the Provider Zip.
	if install == True:
		if xbmcgui.Dialog().yesno('Provider Converter', ' ', 'Would you like to Install the Generated Package?', outputFile):
			xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=installProviders&actionArgs=0)')
		else:
			pass
