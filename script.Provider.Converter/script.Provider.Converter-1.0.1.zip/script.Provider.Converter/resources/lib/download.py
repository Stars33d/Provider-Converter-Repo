# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui
import os, re, urllib, time, zipfile

try:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
except:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

serenZips = xbmc.translatePath(os.path.join(dataPath, 'SerenProviderZips'))
if not os.path.exists(serenZips):
	try: os.makedirs(serenZips)	
	except: pass
zipPath = serenZips if not xbmcaddon.Addon().getSetting('Enable.ZipPath') == False else xbmc.translatePath(xbmcaddon.Addon().getSetting('Custom.ZipPath'))

def download(url, dest, DP = None):
	if not DP:
		DP = xbmcgui.DialogProgress()
		DP.create("Provider Converter","Downloading files...",' ', ' ')
		time.sleep(1)
	DP.update(0)
	start_time=time.time()
	urllib.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, DP, start_time))
	xbmcgui.Dialog().ok("Provider Converter", '', 'Download Complete.')

def _pbhook(numblocks, blocksize, filesize, DP, start_time):
        try:
			percent = min(numblocks * blocksize * 100 / filesize, 100)
			currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
			kbps_speed = numblocks * blocksize / (time.time() - start_time)
			if kbps_speed > 0:
				eta = (filesize - numblocks * blocksize) / kbps_speed
			else:
				eta = 0
			kbps_speed = kbps_speed / 1024
			total = float(filesize) / (1024 * 1024)
			mbs = '%.02f MB of %.02f MB' % (currently_downloaded, total)
			e = 'Speed: %.02f Kb/s ' % kbps_speed
			e += 'ETA: %02d:%02d' % divmod(eta, 60)
			DP.update(percent, mbs, e)
        except:
			percent = 100
			DP.update(percent)
        if DP.iscanceled():
            DP.close()

def getProviderZip(url, install=False):
	# 1) Download the Provider Zip.
	filename = url.rsplit('/', 1)[1]
	download(url, xbmc.translatePath(os.path.join(zipPath, filename)))

	# 2) Install the Provider Zip.
	if install == True:
		if xbmcgui.Dialog().yesno('Provider Converter', ' ', 'Would you like to Install the Downloaded Package?', filename):
			xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=installProviders&actionArgs=0)')
		else:
			pass
