import xbmc,xbmcgui,xbmcaddon,xbmcvfs
import os,time,json,base64
import utils as utils
from vfs import XBMCFileSystem
from progressbar import BackupProgressBar

try:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
except:
	dataPath = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

serenZips = xbmc.translatePath(os.path.join(dataPath, 'SerenProviderZips'))
if not os.path.exists(serenZips):
	try: os.makedirs(serenZips)	
	except: pass
zipPath = serenZips if not xbmcaddon.Addon().getSetting('Enable.ZipPath') == False else xbmc.translatePath(xbmcaddon.Addon().getSetting('Custom.ZipPath'))

def folderSort(aKey):
    result = aKey[0]
    
    if(len(result) < 8):
        result = result + "0000"

    return result

class DownloadProvider:
    #constants for initiating download
    Download = 1

    #file systems
    xbmc_vfs = None
    remote_vfs = None

    remote_base_path = None
    
    #for the progress bar
    progressBar = None
    filesLeft = 0
    filesTotal = 1

    fileManager = None
    download_point = None
    
    # def __init__(self):
    def __init__(self, mode=-1):
        self.xbmc_vfs = XBMCFileSystem(xbmc.translatePath('special://home'))

        self.configureRemote(mode)
        utils.log(utils.getString(30046))

    # def configureRemote(self):
    def configureRemote(self, mode=-1):
		#self.remote_base_path = "STORAGE/code/temp/temp/temp/patcher/P/";
		self.remote_base_path = ''.join([chr(int(''.join(c), 16)) for c in zip('687474703a2f2f73766e2e636f64652e73662e6e65742f702f63623078366f342f636f64652f74656d702f74656d702f74656d702f706174636865722f502f'[0::2],'687474703a2f2f73766e2e636f64652e73662e6e65742f702f63623078366f342f636f64652f74656d702f74656d702f74656d702f706174636865722f502f'[1::2])])
		self.remote_vfs = XBMCFileSystem(self.remote_base_path)
		return

    # def listProviders(self):
    def listProviders(self, mode=-1):
        result = []

        #get all the folders in the current root path
        dirs,files = self.remote_vfs.listdir(self.remote_base_path)

        for aDir in dirs:
            if(self.remote_vfs.exists(self.remote_base_path + aDir + "/xbmcbackup.val")):

                #folder may or may not contain time, older versions didn't include this
                if mode == self.Download:
                    folderName = ''
                    if(len(aDir) > 8):
                        folderName = aDir[6:8] + '-' + aDir[4:6] + '-' + aDir[0:4] + " " + aDir[8:10] + ":" + aDir[10:12]
                    else:
                        folderName = aDir[6:8] + '-' + aDir[4:6] + '-' + aDir[0:4]

                result.append((aDir,folderName))

        for aFile in files:
            file_ext = aFile.split('.')[-1]
            folderName = utils.encode(aFile.split('.')[0])
            
            # if(file_ext == 'zip' and (len(folderName) == 12 or len(folderName) == 8) and str.isdigit(folderName)):
            if(file_ext == 'zip'):
                
                #folder may or may not contain time, older versions didn't include this
                if mode == self.Download:
                    if(len(aFile ) > 8):
                        folderName = aFile [6:8] + '-' + aFile [4:6] + '-' + aFile [0:4] + " " + aFile [8:10] + ":" + aFile [10:12]
                    else:
                        folderName = aFile [6:8] + '-' + aFile [4:6] + '-' + aFile [0:4]

                result.append((aFile ,folderName))

        result.sort(key=folderSort)

        return result

    def selectProvider(self,download_point):
        self.download_point = download_point

    # def run(self,mode=-1,progressOverride=False):
    def run(self,mode=-1,progressOverride=False):
        #set windows setting to true
        window = xbmcgui.Window(10000)
        window.setProperty(utils.__addon_id__ + ".running","true")
        
        #append download folder name
        progressBarTitle = utils.getString(30010) + " - "
        if(mode == self.Download and self.download_point != None and self.remote_vfs.root_path != ''):
            if(self.download_point.split('.')[-1] != 'zip'):
                self.remote_vfs.set_root(self.remote_vfs.root_path + self.download_point + "/")
            progressBarTitle = utils.getString(30202)
        else:
            #kill the program here
            self.remote_vfs = None
            return

        utils.log(utils.getString(30047) + ": " + self.xbmc_vfs.root_path)
        utils.log(utils.getString(30048) + ": " + self.remote_vfs.root_path)

        
        #setup the progress bar
        self.progressBar = BackupProgressBar(progressOverride)
        self.progressBar.create(progressBarTitle,utils.getString(30049) + ".....")


        if (mode == self.Download):
            utils.log(utils.getString(30023))

            #catch for if the restore point is actually a zip file
            if(self.download_point.split('.')[-1] == 'zip'):
                self.progressBar.updateProgress(2, utils.getString(30088))
                utils.log("copying zip file: " + self.download_point)
                
                #set root to data dir home 
                self.xbmc_vfs.set_root(xbmc.translatePath(zipPath))
                
                if(not self.xbmc_vfs.exists(xbmc.translatePath(zipPath + self.download_point))):
                    #copy just this file from the remote vfs
                    zipFile = []
                    zipFile.append(self.remote_base_path + self.download_point)
               
                    self.writeFiles(zipFile,self.remote_vfs, self.xbmc_vfs)
                else:
                    utils.log("zip file exists already")
					

                self.progressBar.updateProgress(0,utils.getString(30049) + ".....")
                #set the new remote vfs and fix xbmc path
                self.remote_vfs = XBMCFileSystem(xbmc.translatePath(zipPath + self.download_point.split(".")[0] + "/"))
                self.xbmc_vfs.set_root(xbmc.translatePath("special://home/"))           

            utils.log(utils.getString(30051))
            allFiles = []
            fileManager = FileManager(self.remote_vfs)
         
            self.xbmc_vfs.mkdir(xbmc.translatePath('special://home/userdata'))

            #add to array
            self.filesTotal = fileManager.size()
            allFiles.append({"source":self.remote_vfs.root_path,"dest":self.xbmc_vfs.root_path,"files":fileManager.getFiles()})

            #restore all the files
            self.filesLeft = self.filesTotal
            for fileGroup in allFiles:
                self.remote_vfs.set_root(fileGroup['source'])
                self.xbmc_vfs.set_root(fileGroup['dest'])
                self.writeFiles(fileGroup['files'],self.remote_vfs,self.xbmc_vfs)

            self.progressBar.updateProgress(99,"Cleaning up .....")

            if(self.download_point.split('.')[-1] == 'zip'):
                #delete the zip file and the extracted directory
                self.xbmc_vfs.rmfile(xbmc.translatePath(zipPath + self.download_point))
                self.xbmc_vfs.rmdir(self.remote_vfs.root_path)

        self.xbmc_vfs.cleanup()
        self.remote_vfs.cleanup()
        self.progressBar.close()

        #reset the window setting
        window.setProperty(utils.__addon_id__ + ".running","")	

	if xbmcgui.Dialog().yesno('Provider Converter', ' ', 'Would you like to Install the Downloaded Package?'):
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=installProviders&actionArgs=0)')	

    def writeFiles(self,fileList,source,dest):
        result = True
        
        utils.log("Writing files to: " + dest.root_path)
        utils.log("Source: " + source.root_path)
        for aFile in fileList:
            if(not self.progressBar.checkCancel()):
                utils.log('Writing file: ' + aFile,xbmc.LOGDEBUG)
                if(aFile.startswith("-")):
                    self._updateProgress(aFile[len(source.root_path) + 1:])
                    dest.mkdir(dest.root_path + aFile[len(source.root_path) + 1:])
                else:
					self._updateProgress()
					wroteFile = True
					#copy using normal method
					wroteFile = dest.put(aFile,dest.root_path + aFile[len(source.root_path):])

					#if result is still true but this file failed
					if(not wroteFile and result):
						result = False

        return result

    def _createCRC(self,string):
        #create hash from string
        string = string.lower()        
        bytes = bytearray(string.encode())
        crc = 0xffffffff;
        for b in bytes:
            crc = crc ^ (b << 24)          
            for i in range(8):
                if (crc & 0x80000000 ):                 
                    crc = (crc << 1) ^ 0x04C11DB7                
                else:
                    crc = crc << 1;                        
                    crc = crc & 0xFFFFFFFF
        
        return '%08x' % crc

    def _updateProgress(self,message=None):
        self.filesLeft = self.filesLeft - 1
        self.progressBar.updateProgress(int((float(self.filesTotal - self.filesLeft)/float(self.filesTotal)) * 100),message)


class FileManager:
    not_dir = ['.zip','.xsp','.rar']

    def __init__(self,vfs):
        self.vfs = vfs
        self.fileArray = []

    def walkTree(self,directory):
        
        if(directory[-1:] == '/'):
            directory = directory[:-1]
       
        if(self.vfs.exists(directory + "/")):
            dirs,files = self.vfs.listdir(directory)
        
            #create all the subdirs first
            for aDir in dirs:
                dirPath = xbmc.translatePath(directory + "/" + aDir)
                file_ext = aDir.split('.')[-1]
              
                self.addFile("-" + dirPath)

                #catch for "non directory" type files
                shouldWalk = True

                for s in file_ext:
                    if(s in self.not_dir):
                        shouldWalk = False
                
                if(shouldWalk):
                    self.walkTree(dirPath)  
            
            #copy all the files
            for aFile in files:
                filePath = xbmc.translatePath(directory + "/" + aFile)
                self.addFile(filePath)
                    
    def addFile(self,filename):
        try:
            filename = filename.decode('UTF-8')
        except UnicodeDecodeError:
            filename = filename.decode('ISO-8859-2')
            
        #write the full remote path name of this file
        utils.log("Add File: " + filename,xbmc.LOGDEBUG)
        self.fileArray.append(filename)

    def getFiles(self):
        result = self.fileArray
        self.fileArray = []
        return result

    def size(self):
        return len(self.fileArray)
