# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin,xbmcvfs,xbmcaddon
import urllib,urllib2,urlparse,re,uuid,time
import os,shutil,subprocess,glob,thread

from datetime import datetime
try:    from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

from resources.lib import convert
from resources.lib import download
#import resources.lib.convert as convert
#import resources.lib.download as download

from resources.lib.downloadV2 import DownloadProvider
from resources.lib import utils

addon_id = 'script.Provider.Converter'
addon = xbmcaddon.Addon('script.Provider.Converter')
dialog = xbmcgui.Dialog()
DP = xbmcgui.DialogProgress()

home = xbmc.translatePath('special://home')
addonPath = xbmc.translatePath(os.path.join(os.path.join(home, 'addons'),'script.Provider.Converter'))
addonicon = xbmc.translatePath(os.path.join(addonPath, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(addonPath, 'fanart.jpg'))
resourcesPath = xbmc.translatePath(os.path.join(addonPath, 'resources'))
mediaPath = xbmc.translatePath(os.path.join(resourcesPath, 'media'))
artPath = xbmc.translatePath(os.path.join(mediaPath, 'art'))
addonsPath = xbmc.translatePath('special://home/addons')
packagesPath = xbmc.translatePath('special://home/addons/packages')
userdataPath = xbmc.translatePath('special://userdata')
databasePath = xbmc.translatePath('special://database')
addondataPath = xbmc.translatePath(os.path.join(userdataPath, 'addon_data'))

lambdaIcon = xbmc.translatePath(os.path.join(addonsPath, 'script.module.lambdascrapers', 'icon.png'))
#lambdaFanart = xbmc.translatePath(os.path.join(addonsPath, 'script.module.lambdascrapers', 'fanart.jpg'))
yodaIcon = xbmc.translatePath(os.path.join(addonsPath, 'script.module.Yoda', 'icon.png'))
#yodaFanart = xbmc.translatePath(os.path.join(addonsPath, 'script.module.Yoda', 'fanart.jpg'))

#######################################################################
#						Define Menus
#######################################################################

def mainMenu():
    #addItem('==================', 'url', 00,os.path.join(addonicon))#########
    addDir('[B][COLOR yellow]Convert[/COLOR][/B] Locally Installed Scraper','url', 1, os.path.join(artPath, "convert.png"), fanart)
    #addDir('[B][COLOR green]Download[/COLOR][/B] Converted Providers','url', 2, os.path.join(artPath, "download.png"), fanart)
    addDir('[B][COLOR green]Download[/COLOR][/B] Converted Providers','url', 8, os.path.join(artPath, "download.png"), fanart)

def convertMenu():	
    addItem('[COLOR yellow]Convert[/COLOR] Local [B]Lambda Scrapers[/B]','url', 3, os.path.join(artPath, lambdaIcon), fanart)
    addItem('[COLOR yellow]Convert[/COLOR] Local [B]Yoda Scrapers[/B]','url', 4, os.path.join(artPath, yodaIcon), fanart)

def downloadMenu():
    addItem('[COLOR green]Download[/COLOR] Converted [B]a4k Scrapers[/B]','url', 5, os.path.join(artPath, "download.png"), fanart)	
    addItem('[COLOR green]Download[/COLOR] Converted [B]Lambda Scrapers[/B]','url', 6, os.path.join(artPath, lambdaIcon), fanart)
    addItem('[COLOR green]Download[/COLOR] Converted [B]Yoda Scrapers[/B]','url', 7, os.path.join(artPath, yodaIcon), fanart)

#######################################################################
#						Add to menus
#######################################################################

def addLink(name,url,iconimage,fanart):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def addDir(name,url,mode,iconimage,fanart):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addItem(name,url,mode,iconimage,fanart):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#######################################################################
#						Parses Choice
#######################################################################

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param 

#######################################################################
#						Remove Functions
#######################################################################	

def removeFile(path):
	#log("Deleting File: %s" % path, xbmc.LOGNOTICE)
	try:    os.remove(path)
	except: return False

def removeFolder(path):
	#log("Deleting Folder: %s" % path, xbmc.LOGNOTICE)
	try: shutil.rmtree(path,ignore_errors=True, onerror=None)
	except: return False

def removePattern(path, pattern):
    for f in os.listdir(path):
        if re.search(pattern, f):
            os.remove(os.path.join(path, f))

def copyFile(path, dest):
	#log("Copying File: %s" % path, xbmc.LOGNOTICE)
	try: shutil.copy(path, dest)
	except: return False

def chmod777(path):	
	#log("Modifying Permissions: %s" % path, xbmc.LOGNOTICE)
	for dirpath, dirnames, filenames in os.walk(path):
		for filename in filenames:
			path = os.path.join(dirpath, filename)
			os.chmod(path, 0o777)

#######################################################################
#						System info
#######################################################################	
		
def sysinfo():
	import socket,requests
	KODIV        = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
	RAMF         = xbmc.getInfoLabel("System.Memory(free)")
	RAMT         = xbmc.getInfoLabel("System.Memory(total)")
	KERNEL       = xbmc.getInfoLabel("System.KernelVersion")
	BUILDVER     = xbmc.getInfoLabel("System.BuildVersion")
	BUILDDATE    = xbmc.getInfoLabel("System.BuildDate")

	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(('8.8.8.8', 0))
	IP = s.getsockname()[0]
			
	open  = requests.get('http://canyouseeme.org/').text
	ip    = re.search('(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)',open)
	EXTIP = str(ip.group())
	
	icon       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
	fanart     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))

	addDir2('[COLOR ff12b2e7][B]Kodi Version[/B][/COLOR]: %s'%KODIV,'url',200,icon,fanart,'')
	addDir2('============================','url',200,icon,fanart,'')	
	addDir2('[B]RAM[/B]: [COLOR green][B]Free[/B][/COLOR]: %s'%RAMF + '  /  [COLOR yellow][B]Total[/B][/COLOR]: %s'%RAMT,'url',200,icon,fanart,'')
	#addDir2('[COLOR green][B]Free Ram[/B][/COLOR]: %s'%RAMF,'url',200,icon,fanart,'')	
	#addDir2('[COLOR yellow][B]Total Ram[/B][/COLOR]: %s'%RAMT,'url',200,icon,fanart,'')
	addDir2('============================','url',200,icon,fanart,'')		
	addDir2('[COLOR red][B]Local IP Address[/B][/COLOR]: %s'%IP,'url',200,icon,fanart,'')
	addDir2('[COLOR red][B]External IP Address[/B][/COLOR]: %s'%EXTIP,'url',200,icon,fanart,'')
	addDir2('============================','url',200,icon,fanart,'')	
	addDir2('[COLOR ffff00ff][B]SYSTEM[/B][/COLOR]: %s'%KERNEL,'url',200,icon,fanart,'')	
	addDir2('[COLOR ffff00ff][B]BUILD[/B][/COLOR]: %s'%BUILDVER + ' - [COLOR red]%s[/COLOR]'%BUILDDATE,'url',200,icon,fanart,'')		

def addDir2(name,url,mode,iconimage,fanart,description):
	import xbmcgui,xbmcplugin,urllib,sys
	u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==10:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	xbmcplugin.endOfDirectory	
			
########################################################################################

def ConvertLS():
	convert.LambdaScrapers(install=False)
	
def InstallLS():
	convert.LambdaScrapers(install=True)	

def ConvertYS():
	convert.YodaScrapers(install=False)

def InstallYS():
	convert.YodaScrapers(install=True)
	
def DownloadA4K():
	url = ''.join([chr(int(''.join(c), 16)) for c in zip('68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f61346b53637261706572732d302e302e352e7a6970'[0::2],'68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f61346b53637261706572732d302e302e352e7a6970'[1::2])])
	download.getProviderZip(url, True)
	
def DownloadLS():
	url = ''.join([chr(int(''.join(c), 16)) for c in zip('68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f4c616d62646153637261706572732d302e302e312e7a6970'[0::2],'68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f4c616d62646153637261706572732d302e302e312e7a6970'[1::2])])
	download.getProviderZip(url, True)

def DownloadYS():
	url = ''.join([chr(int(''.join(c), 16)) for c in zip('68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f596f646153637261706572732d312e30302e3034352e7a6970'[0::2],'68747470733a2f2f73766e2e636f64652e73662e6e65742f702f6963616e75636b78626d637265706f2f70726f7669646572636f6e7665727465722f536572656e50726f76696465725a6970732f596f646153637261706572732d312e30302e3034352e7a6970'[1::2])])
	download.getProviderZip(url, True)

def Download(mode=-1):
	mode = 0

	#check if program should be run
	if(mode != -1):
		mode += 2

		downloadv2 = DownloadProvider(mode)

		#get list of valid providers
		downloadPoints = downloadv2.listProviders(mode)
		fileNames = []
		folderNames = []
		
		for aDir in downloadPoints:
			fileNames.append(aDir[1])
			folderNames.append(aDir[0])

		#allow user to select the provider to download
		selectedProvider = xbmcgui.Dialog().select(utils.getString(30021),fileNames)

		downloadv2.selectProvider(downloadPoints[selectedProvider][0])
	
		mode = downloadv2.Download								

		downloadv2.run(mode)

#######################################################################
#						START MAIN
#######################################################################              

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
        mainMenu()

elif mode==1:
        convertMenu()

elif mode==2:
        downloadMenu()

elif mode==3:
		#ConvertLS
		InstallLS()

elif mode==4:
        #ConvertYS()
        InstallYS()

elif mode==5:
        DownloadA4K()

elif mode==6:
        DownloadLS()

elif mode==7:
        DownloadYS()
		
elif mode==8:
		Download(mode=-1)

elif mode==99:
		sysinfo()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
