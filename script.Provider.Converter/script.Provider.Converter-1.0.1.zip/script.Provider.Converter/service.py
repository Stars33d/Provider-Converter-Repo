# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, os, sys, time

sourcesxml = xbmc.translatePath(os.path.join('special://userdata', 'sources.xml'))

providerInstaller = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.seren', 'resources', 'lib', 'modules', 'providerInstaller.py'))

if xbmcaddon.Addon().getSetting('Sources.ZipPath') == 'true':
	if not '<name>[B]* Seren Provider Zips *[/B]</name>' in open(sourcesxml).read():
		time.sleep(5)
		if xbmcgui.Dialog().yesno('Provider Converter', 'Would you like to Add the [B]Seren Provider Zip[/B] folder to your Kodi Sources?', 'This will make it easier to install converted providers.', '[B][COLOR red]Warning:[/COLOR][/B] This will modify your [B]Sources.xml[/B] file'):
			#add Seren Provider Zip folder to sources.xml
			string ="    <files>\
					 \n        <source>\
					 \n            <name>[B]* Seren Provider Zips *[/B]</name>\
					 \n            <path pathversion='1'>special://userdata/addon_data/script.Provider.Converter/SerenProviderZips/</path>\
					 \n            <allowsharing>true</allowsharing>\
					 \n        </source>\
					"
			try:
				r = open(sourcesxml).read()
				w = open(sourcesxml, mode = 'w' )
				w.write( r.replace('<files>', string))
			except:
				xbmcgui.Dialog().ok('Provider Converter', 'Failed to Add the [B]Seren Provider Zip[/B] folder to your Kodi Sources!')
				sys.exit()

			try:
				#modify seren to translate zip_location - providerInstaller.py - line#59
				r = open(providerInstaller).read()
				w = open(providerInstaller, mode = 'w' )
				w.write( r.replace('file = zipfile.ZipFile(zip_location)', 'file = zipfile.ZipFile(xbmc.translatePath(zip_location))'))
			except:
				xbmcgui.Dialog().ok('Provider Converter', 'Failed to Add the [B]Seren Provider Zip[/B] folder to your Kodi Sources!')
				sys.exit()

			if xbmcgui.Dialog().yesno('Provider Converter', 'Successfully Added the [B]Seren Provider Zip[/B] folder to Kodi Sources.', 'Kodi needs to Close to Complete the Operation.', 'Select Yes to Continue'):
				os._exit(1)
		else:
			xbmcaddon.Addon().setSetting('Sources.ZipPath', 'false')
