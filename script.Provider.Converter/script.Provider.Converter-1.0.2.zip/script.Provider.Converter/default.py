# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcplugin
import urllib,re,os

from resources.lib import convert
from resources.lib import download
from resources.lib import utils
from resources.lib.downloadV2 import DownloadProvider

#######################################################################
#						Define Menus
#######################################################################

def mainMenu():
	#utils.addItem('==================', 'url', 00,os.path.join(utils.addonicon))#########
	utils.addDir(utils.getString(30013),'url', 1, 'convert', utils.fanart)
	#utils.addDir(utils.getString(30014),'url', 2, 'download', utils.fanart)
	utils.addDir(utils.getString(30014),'url', 8, 'download', utils.fanart)
	utils.addDir(utils.getString(30028),'url', 9, 'clear', utils.fanart)

def convertMenu():	
    utils.addItem(utils.getString(30015),'url', 3, os.path.join(utils.artPath, utils.lambdaIcon), utils.fanart)
    utils.addItem(utils.getString(30016),'url', 4, os.path.join(utils.artPath, utils.yodaIcon), utils.fanart)

#version1
def downloadMenu():
    utils.addItem('[COLOR green]Download[/COLOR] Converted [B]a4k Scrapers[/B]','url', 5, os.path.join(utils.artPath, "download.png"), utils.fanart)	
    utils.addItem('[COLOR green]Download[/COLOR] Converted [B]Lambda Scrapers[/B]','url', 6, os.path.join(utils.artPath, utils.lambdaIcon), utils.fanart)
    utils.addItem('[COLOR green]Download[/COLOR] Converted [B]Yoda Scrapers[/B]','url', 7, os.path.join(utils.artPath, utils.yodaIcon), utils.fanart)

#######################################################################
#						Parses Choice
#######################################################################

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]

	return param

########################################################################################

def ConvertLS():
	convert.LambdaScrapers(install=False)

def InstallLS():
	convert.LambdaScrapers(install=True)	

def ConvertYS():
	convert.YodaScrapers(install=False)

def InstallYS():
	convert.YodaScrapers(install=True)

def DownloadA4K():
	url = utils.decode('Njg3NDc0NzA3MzNhMmYyZjczNzY2ZTJlNjM2ZjY0NjUyZTczNjYyZTZlNjU3NDJmNzAyZjY5NjM2MTZlNzU2MzZiNzg2MjZkNjM3MjY1NzA2ZjJmNzA3MjZmNzY2OTY0NjU3MjYzNmY2ZTc2NjU3Mjc0NjU3MjJmNTM2NTcyNjU2ZTUwNzI2Zjc2Njk2NDY1NzI1YTY5NzA3MzJmNjEzNDZiNTM2MzcyNjE3MDY1NzI3MzJkMzAyZTMwMmUzNTJlN2E2OTcw')
	download.getProviderZip(url, True)

def DownloadLS():
	url = utils.decode('Njg3NDc0NzA3MzNhMmYyZjczNzY2ZTJlNjM2ZjY0NjUyZTczNjYyZTZlNjU3NDJmNzAyZjY5NjM2MTZlNzU2MzZiNzg2MjZkNjM3MjY1NzA2ZjJmNzA3MjZmNzY2OTY0NjU3MjYzNmY2ZTc2NjU3Mjc0NjU3MjJmNTM2NTcyNjU2ZTUwNzI2Zjc2Njk2NDY1NzI1YTY5NzA3MzJmNGM2MTZkNjI2NDYxNTM2MzcyNjE3MDY1NzI3MzJkMzAyZTMwMmUzMTJlN2E2OTcw')
	download.getProviderZip(url, True)

def DownloadYS():
	url = utils.decode('Njg3NDc0NzA3MzNhMmYyZjczNzY2ZTJlNjM2ZjY0NjUyZTczNjYyZTZlNjU3NDJmNzAyZjY5NjM2MTZlNzU2MzZiNzg2MjZkNjM3MjY1NzA2ZjJmNzA3MjZmNzY2OTY0NjU3MjYzNmY2ZTc2NjU3Mjc0NjU3MjJmNTM2NTcyNjU2ZTUwNzI2Zjc2Njk2NDY1NzI1YTY5NzA3MzJmNTk2ZjY0NjE1MzYzNzI2MTcwNjU3MjczMmQzMTJlMzAzMDJlMzAzNDM1MmU3YTY5NzA=')
	download.getProviderZip(url, True)

def Download():
	downloadv2 = DownloadProvider()

	#get list of valid providers
	downloadPoints = downloadv2.listProviders()
	fileNames = []
	folderNames = []

	for aDir in downloadPoints:
		fileNames.append(aDir[0])
		folderNames.append(aDir[0])

	#allow user to select the provider to download
	selectedProvider = xbmcgui.Dialog().select(utils.getString(30030),fileNames)

	downloadv2.selectProvider(downloadPoints[selectedProvider][0])

	downloadv2.run(downloadv2)

def ClearZipDir():
	if os.path.exists(utils.serenZips):
		utils.removeFolder(utils.serenZips)
		xbmcgui.Dialog().ok(utils.getString(30010), '', utils.getString(30029))
		sys.exit()
	else:
		pass

#######################################################################
#						START MAIN
#######################################################################              

params=get_params()
url=None
name=None
mode=None

try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

if mode==None or url==None or len(url)<1:
	mainMenu()

elif mode==1:
	convertMenu()

elif mode==2:
	downloadMenu()

elif mode==3:
	#ConvertLS
	InstallLS()

elif mode==4:
	#ConvertYS()
	InstallYS()

elif mode==5:
	DownloadA4K()

elif mode==6:
	DownloadLS()

elif mode==7:
	DownloadYS()
		
elif mode==8:
	Download()

elif mode==9:
	ClearZipDir()

elif mode==99:
	utils.sysinfo()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
