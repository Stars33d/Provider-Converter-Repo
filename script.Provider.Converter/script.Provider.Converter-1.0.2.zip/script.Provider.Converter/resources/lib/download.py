# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui
import os,re,urllib,time,zipfile
from resources.lib import utils

serenZips = xbmc.translatePath(os.path.join(utils.dataPath(), 'SerenProviderZips'))
if not os.path.exists(serenZips):
	try: os.makedirs(serenZips)	
	except: pass
zipPath = serenZips if not utils.getSetting('Enable.ZipPath') == False else xbmc.translatePath(utils.getSetting('Custom.ZipPath'))

def download(url, dest, DP = None):
	if not DP:
		DP = xbmcgui.DialogProgress()
		DP.create(utils.getString(30010),"Downloading files...",' ', ' ')
		time.sleep(1)
	DP.update(0)
	start_time=time.time()
	urllib.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, DP, start_time))
	xbmcgui.Dialog().ok(utils.getString(30010), '', 'Download Complete.')

def _pbhook(numblocks, blocksize, filesize, DP, start_time):
        try:
			percent = min(numblocks * blocksize * 100 / filesize, 100)
			currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
			kbps_speed = numblocks * blocksize / (time.time() - start_time)
			if kbps_speed > 0:
				eta = (filesize - numblocks * blocksize) / kbps_speed
			else:
				eta = 0
			kbps_speed = kbps_speed / 1024
			total = float(filesize) / (1024 * 1024)
			mbs = '%.02f MB of %.02f MB' % (currently_downloaded, total)
			e = 'Speed: %.02f Kb/s ' % kbps_speed
			e += 'ETA: %02d:%02d' % divmod(eta, 60)
			DP.update(percent, mbs, e)
        except:
			percent = 100
			DP.update(percent)
        if DP.iscanceled():
            DP.close()

def getProviderZip(url, install=False):
	#Download the Provider Zip.
	filename = url.rsplit('/', 1)[1]
	download(url, xbmc.translatePath(os.path.join(zipPath, filename)))

	#Install the Provider Zip.
	if install == True:
		if xbmcgui.Dialog().yesno(utils.getString(30010), ' ', utils.getString(30010), filename):
			xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=installProviders&actionArgs=0)')
		else:
			pass
