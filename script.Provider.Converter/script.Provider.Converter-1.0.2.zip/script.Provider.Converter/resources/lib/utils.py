import xbmc,xbmcgui,xbmcaddon,xbmcplugin
import urllib,os,sys,shutil,base64

__addon_id__= 'script.Provider.Converter'
__Addon = xbmcaddon.Addon(__addon_id__)
addonIcon = xbmc.translatePath(__Addon.getAddonInfo('path') + "/icon.png")

home = xbmc.translatePath('special://home')
addonPath = __Addon.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(addonPath, 'fanart.jpg'))
resourcesPath = xbmc.translatePath(os.path.join(addonPath, 'resources'))
mediaPath = xbmc.translatePath(os.path.join(resourcesPath, 'media'))
artPath = xbmc.translatePath(os.path.join(mediaPath, 'art'))
addonsPath = xbmc.translatePath('special://home/addons')
packagesPath = xbmc.translatePath('special://home/addons/packages')
userdataPath = xbmc.translatePath('special://userdata')
databasePath = xbmc.translatePath('special://database')

lambdaIcon = xbmc.translatePath(os.path.join(addonsPath, 'script.module.lambdascrapers', 'icon.png'))
lambdaFanart = xbmc.translatePath(os.path.join(addonsPath, 'script.module.lambdascrapers', 'fanart.jpg'))
yodaIcon = xbmc.translatePath(os.path.join(addonsPath, 'script.module.Yoda', 'icon.png'))
yodaFanart = xbmc.translatePath(os.path.join(addonsPath, 'script.module.Yoda', 'fanart.jpg'))

def dataPath():
	try:
		return __Addon.getAddonInfo('profile').decode('utf-8')
	except:
		return __Addon.getAddonInfo('profile')
		
serenZips = xbmc.translatePath(os.path.join(dataPath(), 'SerenProviderZips'))

def addonPath():
    return __Addon.getAddonInfo('path')

def iconPath(iconname):
	return os.path.join(artPath, iconname+'.png')

def openSettings():
    __Addon.openSettings()

def log(message,loglevel=xbmc.LOGNOTICE):
    xbmc.log(encode(__addon_id__ + "-" + __Addon.getAddonInfo('version') +  ": " + message),level=loglevel)

def showNotification(message):
    xbmcgui.Dialog().notification(encode(getString(30022)),encode(message),time=4000,icon=addonIcon)

def getSetting(name):
    return __Addon.getSetting(name)

def setSetting(name,value):
    __Addon.setSetting(name,value)
    
def getString(string_id):
    return __Addon.getLocalizedString(string_id)

def encode(string):
    result = ''

    try:
        result = string.encode('UTF-8','replace')
    except UnicodeDecodeError:
        result = 'Unicode Error'
    
    return result

def decode(string):	
	return ''.join([chr(int(''.join(c), 16)) for c in zip(base64.b64decode(string)[0::2],base64.b64decode(string)[1::2])])

#######################################################################
#						Remove Functions
#######################################################################	

def removeFile(path):
	#log("Deleting File: %s" % path, xbmc.LOGNOTICE)
	try:    os.remove(path)
	except: return False

def removeFolder(path):
	#log("Deleting Folder: %s" % path, xbmc.LOGNOTICE)
	try: shutil.rmtree(path,ignore_errors=True, onerror=None)
	except: return False

def removePattern(path, pattern):
    for f in os.listdir(path):
        if re.search(pattern, f):
            os.remove(os.path.join(path, f))

def copyFile(path, dest):
	#log("Copying File: %s" % path, xbmc.LOGNOTICE)
	try: shutil.copy(path, dest)
	except: return False

def chmod777(path):	
	#log("Modifying Permissions: %s" % path, xbmc.LOGNOTICE)
	for dirpath, dirnames, filenames in os.walk(path):
		for filename in filenames:
			path = os.path.join(dirpath, filename)
			os.chmod(path, 0o777)

#######################################################################
#						Add to menus
#######################################################################

def addLink(name,url,iconimage,fanart):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def addDir(name,url,mode,iconname,fanart):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconPath(iconname))
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addDir2(name,url,mode,iconimage,fanart,description):
	import xbmcgui,xbmcplugin,urllib,sys
	u=sys.argv[0]+"?url="+url+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
	xbmcplugin.endOfDirectory

def addItem(name,url,mode,iconimage,fanart):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

#######################################################################
#						System info
#######################################################################	
		
def sysinfo():
	import socket,requests
	KODIV        = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
	RAMF         = xbmc.getInfoLabel("System.Memory(free)")
	RAMT         = xbmc.getInfoLabel("System.Memory(total)")
	KERNEL       = xbmc.getInfoLabel("System.KernelVersion")
	BUILDVER     = xbmc.getInfoLabel("System.BuildVersion")
	BUILDDATE    = xbmc.getInfoLabel("System.BuildDate")

	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(('8.8.8.8', 0))
	IP = s.getsockname()[0]
			
	open  = requests.get('http://canyouseeme.org/').text
	ip    = re.search('(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)',open)
	EXTIP = str(ip.group())

	addDir2('[COLOR ff12b2e7][B]Kodi Version[/B][/COLOR]: %s'%KODIV,'url',200,utils.addonIcon,utils.fanart,'')
	addDir2('============================','url',200,utils.addonIcon,utils.fanart,'')	
	addDir2('[B]RAM[/B]: [COLOR green][B]Free[/B][/COLOR]: %s'%RAMF + '  /  [COLOR yellow][B]Total[/B][/COLOR]: %s'%RAMT,'url',200,utils.addonIcon,utils.fanart,'')
	#addDir2('[COLOR green][B]Free Ram[/B][/COLOR]: %s'%RAMF,'url',200,utils.addonIcon,utils.fanart,'')	
	#addDir2('[COLOR yellow][B]Total Ram[/B][/COLOR]: %s'%RAMT,'url',200,utils.addonIcon,utils.fanart,'')
	addDir2('============================','url',200,utils.addonIcon,utils.fanart,'')		
	addDir2('[COLOR red][B]Local IP Address[/B][/COLOR]: %s'%IP,'url',200,utils.addonIcon,utils.fanart,'')
	addDir2('[COLOR red][B]External IP Address[/B][/COLOR]: %s'%EXTIP,'url',200,utils.addonIcon,utils.fanart,'')
	addDir2('============================','url',200,utils.addonIcon,utils.fanart,'')	
	addDir2('[COLOR ffff00ff][B]SYSTEM[/B][/COLOR]: %s'%KERNEL,'url',200,utils.addonIcon,utils.fanart,'')	
	addDir2('[COLOR ffff00ff][B]BUILD[/B][/COLOR]: %s'%BUILDVER + ' - [COLOR red]%s[/COLOR]'%BUILDDATE,'url',200,utils.addonIcon,utils.fanart,'')
