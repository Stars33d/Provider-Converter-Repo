# -*- coding: utf-8 -*-

import xbmc,xbmcaddon,xbmcgui
import os, sys, time
from resources.lib import utils

sourcesxml = xbmc.translatePath(os.path.join('special://userdata', 'sources.xml'))

#providerInstaller = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.seren', 'resources', 'lib', 'modules', 'providerInstaller.py'))

if utils.getSetting('Sources.ZipPath') == 'true':
	if not '<name>[B]* Seren Provider Zips *[/B]</name>' in open(sourcesxml).read():
		time.sleep(5)
		if xbmcgui.Dialog().yesno(utils.getString(30010), utils.getString(30025), utils.getString(30026), utils.getString(30027)):
			#add Seren Provider Zip folder to sources.xml
			string ="    <files>\
					 \n        <source>\
					 \n            <name>[B]* Seren Provider Zips *[/B]</name>\
					 \n            <path pathversion='1'>special://userdata/addon_data/script.Provider.Converter/SerenProviderZips/</path>\
					 \n            <allowsharing>true</allowsharing>\
					 \n        </source>\
					"
			try:
				r = open(sourcesxml).read()
				w = open(sourcesxml, mode = 'w' )
				w.write( r.replace('<files>', string))
			except:
				xbmcgui.Dialog().ok(utils.getString(30010), utils.getString(30021))
				sys.exit()

			#modify seren for special protocol - depreciated - added to Seren
			#try:
				#modify seren to translate zip_location - providerInstaller.py - line#59
			#	r = open(providerInstaller).read()
			#	w = open(providerInstaller, mode = 'w' )
			#	w.write( r.replace('file = zipfile.ZipFile(zip_location)', 'file = zipfile.ZipFile(xbmc.translatePath(zip_location))'))
			#except:
			#	xbmcgui.Dialog().ok(utils.getString(30010), utils.getString(30021))
			#	sys.exit()

			if xbmcgui.Dialog().yesno(utils.getString(30010), utils.getString(30022), utils.getString(30023), utils.getString(30024)):
				os._exit(1)
		else:
			xbmcaddon.Addon().setSetting('Sources.ZipPath', 'false')
